# Complex Numbers
 
##### Package that is used to convert real numbers into complex numbers using the function complex(x,y).

# Installation

 Run the following to install :

```cmd pip install complex-numbers```

### Contributor : Vidhya Lakshmi D
### Mentor : Maria Irudaya Regilan J
